﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework
{
    public partial class godown_detail : Form
    {
        public godown_detail()
        {
            InitializeComponent();
        }

        private void godown_detail_Load(object sender, EventArgs e)
        {
            this.listView1.Columns.Add("商品编号");
            this.listView1.Columns.Add("名称");
            this.listView1.Columns.Add("类型");
            this.listView1.Columns.Add("价格");
            this.listView1.Columns.Add("计数单位");
            this.listView1.Columns.Add("数量");
            this.listView1.Columns.Add("仓库编号");
            this.listView1.View = System.Windows.Forms.View.Details;
            Go_Come.goods_max[] good_max = new Go_Come.goods_max[100];
            Go_Come gc = new Go_Come();
            gc.loadfile(good_max);
            listView1.Items.Clear();
            for (int i = 0; i < gc.totalnum; i++)
            {
                if (godown.a == good_max[i].gd_num)
                {
                    ListViewItem lv = new ListViewItem();
                    lv.Text = good_max[i].num;
                    lv.SubItems.Add(good_max[i].name);
                    lv.SubItems.Add(good_max[i].type);
                    lv.SubItems.Add(good_max[i].price.ToString());
                    lv.SubItems.Add(good_max[i].unitage);
                    lv.SubItems.Add(good_max[i].quantity.ToString());
                    lv.SubItems.Add(good_max[i].gd_num);
                    this.listView1.Items.Add(lv);
                }
            }
        }
    }
}

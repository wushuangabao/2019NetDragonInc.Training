﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework
{
    public partial class Change_merchandise : Form
    {
        Merchandise.goods[] good = new Merchandise.goods[100];
        public Change_merchandise()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//确定
        {
            int isEmpty = 1;
            int isSave = 1;
            Merchandise mc = new Merchandise();
            mc.loadfile( good);
            for (int i = 0; i < mc.totalnum; i++)
            {
                if (good[i].num == Merchandise.need_change)//对商品编号的修改
                {
                    if (textBox1.Text.Trim() != String.Empty)
                    {
                        for (int j = 0; j < good.Length; j++)
                        {
                            if (textBox1.Text == good[j].num)
                            {
                                MessageBox.Show("该编号已存在");
                                isSave = 0;
                                break;
                            }
                        }
                        good[i].num = textBox1.Text;
                        isEmpty = 0;
                    }
                    if (textBox2.Text.Trim() != String.Empty)
                    {
                        for (int j = 0; j < good.Length; j++)
                        {
                            if (textBox2.Text == good[j].num)
                            {
                                MessageBox.Show("该名称已存在");
                                isSave = 0;
                                break;
                            }
                        }
                        good[i].name = textBox2.Text;
                        isEmpty = 0;
                    }
                    if (textBox3.Text.Trim() != String.Empty)
                    {
                        good[i].type = textBox3.Text;
                        isEmpty = 0;
                    }
                    if (textBox4.Text.Trim() != String.Empty)
                    {
                        good[i].price= float.Parse(textBox4.Text);
                        isEmpty = 0;
                    }
                    if (textBox5.Text.Trim() != String.Empty)
                    {
                        good[i].unitage = textBox5.Text;
                        isEmpty = 0;
                    }
                    if (textBox6.Text.Trim() != String.Empty)
                    {
                        good[i].quantity = int.Parse(textBox6.Text);
                        isEmpty = 0;
                    }
                    break;
                }
            }
            if (isEmpty == 1)
            {
                MessageBox.Show("文本框不能全为空！");
            }
            if (isSave == 0)
            {
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
            }
            else {
                mc.savefile( good);
                MessageBox.Show("修改成功，请刷新！");
                this.Close();
            }

            
        }

        private void Change_merchandise_Load(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)//清空
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
        }

        private void button3_Click(object sender, EventArgs e)//取消
        {
            this.Close();
        }
    }
}

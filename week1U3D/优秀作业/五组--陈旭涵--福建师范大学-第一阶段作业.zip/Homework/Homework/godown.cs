﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Homework
{
    public partial class godown : Form
    {
        public static String a;
        public struct warehouses//仓库基本信息结构体
        {
            public String num;//编号
            public String addr;//地址
        }
        private warehouses[] warehouse = new warehouses[100];
        public int totalnum = 0;//当前仓库种类总数
        public static String need_change;
        public void loadfile(warehouses[] b)//读取txt文件
        {
            StreamReader sw = new StreamReader("warehouse.txt");
            totalnum = 0;
            String line;
            String[] a = new String[2];
            int i = 0;
            while ((line = sw.ReadLine()) != null)
            {
                a = line.Split(' ');
                b[i].num = a[0];
                b[i].addr = a[1];
                i++;
                totalnum++;
            }
            sw.Close();
        }
        public void savefile(warehouses[] b)//保存txt文件
        {
            FileStream sw = new FileStream("warehouse.txt", FileMode.Create, FileAccess.Write);
            sw.SetLength(0);//清空txt文本
            sw.Close();
            StreamWriter sr = new StreamWriter("warehouse.txt", true);
            for (int i = 0; i < totalnum; i++)
            {
                sr.WriteLine(b[i].num + " " + b[i].addr);
            }

            sr.Close();
        }
        public void update()//刷新
        {
            listView1.Items.Clear();
            totalnum = 0;
            loadfile(warehouse);
            for (int i = 0; i < totalnum; i++)
            {
                ListViewItem lv = new ListViewItem();
                lv.Text = warehouse[i].num;
                lv.SubItems.Add(warehouse[i].addr);
                this.listView1.Items.Add(lv);
            }
        }
        public godown()
        {
            InitializeComponent();
        }
        
        private void godown_Load(object sender, EventArgs e)
        {
            this.listView1.Columns.Add("仓库编号");
            this.listView1.Columns.Add("地址");
            this.listView1.View = System.Windows.Forms.View.Details;
            update();
        }

        private void button1_Click(object sender, EventArgs e)//增加
        {
            Add_godown ag = new Add_godown();
            ag.Show();
        }

        private void button5_Click(object sender, EventArgs e)//刷新
        {
            update();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            loadfile(warehouse);
            ListView lv = this.listView1;
            if (lv.SelectedItems.Count > 0)
            {
                for (int i = 0; i < totalnum; i++)
                {

                    if (lv.SelectedItems[0].SubItems[0].Text == warehouse[i].num)
                    {
                        for (int j = i; j < totalnum - 1; j++)
                        {
                            warehouse[i] = warehouse[i + 1];
                        }
                        totalnum--;
                        break;
                    }
                }
            }
            savefile(warehouse);
            MessageBox.Show("删除成功！");
            update();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Search_godown sg = new Search_godown();
            sg.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ListView lv = this.listView1;
            if (lv.SelectedItems.Count > 0)
            {
                need_change = lv.SelectedItems[0].SubItems[0].Text;
                Change_godown cg = new Change_godown();
                cg.Show();
            }
            else
            {
                MessageBox.Show("请在左边列表中选择要修改的项！");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)//查找库存商品
        {
            if (listView1.SelectedItems.Count > 0)
            {
                a = listView1.SelectedItems[0].SubItems[0].Text;
                godown_detail gd = new godown_detail();
                gd.Show();
            }
            else
            {
                MessageBox.Show("请在左边列表中选择要查询的仓库！");
            }
        }
    }
}

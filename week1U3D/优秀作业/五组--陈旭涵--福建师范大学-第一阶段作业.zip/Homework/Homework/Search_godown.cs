﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework
{
    public partial class Search_godown : Form
    {
        godown.warehouses[] warehouse = new godown.warehouses[100];
        public Search_godown()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)//清空
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button3_Click(object sender, EventArgs e)//关闭
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)//查询
        {
            listView1.Items.Clear();
            godown gd = new godown();
            gd.loadfile(warehouse);
            for (int i = 0; i < gd.totalnum; i++)
            {
                if ((textBox1.Text.Trim() == String.Empty || textBox1.Text == warehouse[i].num) &&
                    (textBox2.Text.Trim() == String.Empty || textBox2.Text == warehouse[i].addr))
                {
                    ListViewItem lv = new ListViewItem();
                    lv.Text = warehouse[i].num;
                    lv.SubItems.Add(warehouse[i].addr);
                    this.listView1.Items.Add(lv);
                }
            }
            MessageBox.Show("查询完成！");
            textBox1.Clear();
            textBox2.Clear();
        }

        private void Search_godown_Load(object sender, EventArgs e)
        {
            this.listView1.Columns.Add("仓库编号");
            this.listView1.Columns.Add("地址");
            this.listView1.View = System.Windows.Forms.View.Details;
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

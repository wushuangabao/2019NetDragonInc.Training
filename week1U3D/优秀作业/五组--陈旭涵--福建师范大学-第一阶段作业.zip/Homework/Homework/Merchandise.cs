﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Homework
{
    
    public partial class Merchandise : Form
    {
        private goods[] good = new goods[100];
        public static String need_change;
        public int totalnum = 0;//当前商品种类总数
        public struct goods//商品基本信息结构体
        {
            public String num;//编号
            public String name;//名称
            public String type;//类型
            public float price;//价格
            public String unitage;//计数单位
            public int quantity;//数量
        }
        public void loadfile( goods[]b)//读取txt文件
        {
            StreamReader sr = new StreamReader("goods.txt");
            totalnum = 0;
            String line;
            String[] a = new String[6];
            int i = 0;
            while ((line = sr.ReadLine()) != null)
            {
                a = line.Split(' ');
                b[i].num = a[0];
                b[i].name = a[1];
                b[i].type = a[2];
                b[i].price = float.Parse(a[3]);
                b[i].unitage = a[4];
                b[i].quantity = int.Parse(a[5]);
                i++;
                totalnum++;
            }
            sr.Close();
        }
        public void savefile(goods[] b)//保存txt文件
        {
            FileStream sw = new FileStream("goods.txt", FileMode.Create, FileAccess.Write);
            sw.SetLength(0);//清空txt文本
            sw.Close();
            StreamWriter sr = new StreamWriter("goods.txt", true);
            for (int i = 0; i < totalnum; i++)
            {
                sr.WriteLine(b[i].num + " " + b[i].name + " " + b[i].type + " " + b[i].price.ToString() + " " + b[i].unitage + " " + b[i].quantity.ToString());
            }
            
            sr.Close();
        }
       
        public void update()//刷新
        {
            listView1.Items.Clear();
            totalnum = 0;
            loadfile( good);
           for (int i = 0; i <totalnum; i++)
            {
                ListViewItem lv = new ListViewItem();
                lv.Text = good[i].num;
                lv.SubItems.Add(good[i].name);
                lv.SubItems.Add(good[i].type);
                lv.SubItems.Add(good[i].price.ToString());
                lv.SubItems.Add(good[i].unitage);
                lv.SubItems.Add(good[i].quantity.ToString());
                this.listView1.Items.Add(lv);
            }
        }
        public Merchandise()
        {
            InitializeComponent();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Merchandise_Load(object sender, EventArgs e)
        {
            this.listView1.Columns.Add("商品编号");
            this.listView1.Columns.Add("名称");
            this.listView1.Columns.Add("类型");
            this.listView1.Columns.Add("单价");
            this.listView1.Columns.Add("计量单位");
            this.listView1.Columns.Add("数量");
            this.listView1.View = System.Windows.Forms.View.Details;
            update();
        }

        private void button1_Click(object sender, EventArgs e)//增加
        {
            Add_merchandise add_mer = new Add_merchandise();
            add_mer.Show();
        }

        private void button5_Click(object sender, EventArgs e)//刷新
        {
            update();
        }
        private void button2_Click(object sender, EventArgs e)//查询
        {
            Search_Merchandise sm = new Search_Merchandise();
            sm.Show();
        }

        private void button4_Click(object sender, EventArgs e)//修改
        {
            ListView lv = this.listView1;
            if (lv.SelectedItems.Count > 0)
            {
                need_change= lv.SelectedItems[0].SubItems[0].Text;
                Change_merchandise cm = new Change_merchandise();
                cm.Show();
            }
            else
            {
                MessageBox.Show("请在左边列表中选择要修改的项！");
            }
        }

        private void button3_Click(object sender, EventArgs e)//删除
        {
            loadfile( good);
            ListView lv = this.listView1;
            if (lv.SelectedItems.Count > 0)
            {
                for (int i = 0; i < totalnum; i++)
                {
                    
                    if (lv.SelectedItems[0].SubItems[0].Text == good[i].num)
                    {
                        for (int j =i; j<totalnum-1; j++)
                        {
                            good[i] = good[i + 1];
                        }
                        totalnum--;
                        break;
                    }
                }
            }
            savefile( good);
            MessageBox.Show("删除成功！");
            update();
        }

        private void button6_Click(object sender, EventArgs e)//退出
        {
            this.Close();
        }
    }
}

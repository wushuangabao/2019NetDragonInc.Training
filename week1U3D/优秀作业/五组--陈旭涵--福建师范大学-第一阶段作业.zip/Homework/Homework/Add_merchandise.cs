﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Homework
{
    public partial class Add_merchandise : Form
    {
        Merchandise mer = new Merchandise();
        Merchandise.goods []good = new Merchandise.goods[100];
        public Add_merchandise()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)//确定
        {
            mer.loadfile( good);
            int flag = 0;
            if (textBox1.Text.Trim()== String.Empty || textBox2.Text.Trim() == String.Empty || textBox3.Text.Trim() == String.Empty 
                || textBox4.Text.Trim() == String.Empty || textBox5.Text.Trim() == String.Empty || textBox6.Text.Trim() == String.Empty)
            {
                flag = 3;
            }
            for (int i = 0; i < mer.totalnum; i++)
            {
                if (good[i].num == textBox1.Text)
                {
                    flag = 1;
                    break;
                }
                if (good[i].name == textBox2.Text)
                {
                    flag = 2;
                    break;
                }
            }
            if (flag == 0)
            {
                good[mer.totalnum].num = textBox1.Text;
                good[mer.totalnum].name = textBox2.Text;
                good[mer.totalnum].type = textBox3.Text;
                good[mer.totalnum].price = float.Parse(textBox4.Text);
                good[mer.totalnum].unitage = textBox5.Text;
                good[mer.totalnum].quantity = int.Parse(textBox6.Text);
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                mer.totalnum++;
                mer.savefile(good);
                MessageBox.Show("添加成功,请刷新！");
                this.Close();
            }
            if (flag == 1)
            {
                MessageBox.Show("该商品编号已存在");
            }
            if (flag == 2)
            {
                MessageBox.Show("该商品名称已存在");
            }
            if (flag == 3)
            {
                MessageBox.Show("信息填写不完整！");
            }
        }//确定

        private void button2_Click(object sender, EventArgs e)//清除
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
        }

        private void button3_Click(object sender, EventArgs e)//取消
        {
            this.Close();
        }

        private void Add_merchandise_Load(object sender, EventArgs e)
        {

        }
    }
}

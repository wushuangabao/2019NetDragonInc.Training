﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework
{
    public partial class Add_Shlef : Form
    {
        Shelf gd = new Shelf();
        Shelf.goodshelfs[] goodshelf = new Shelf.goodshelfs[100];
        public Add_Shlef()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            gd.loadfile(goodshelf);
            int flag = 0;
            if (textBox1.Text.Trim() == String.Empty || textBox2.Text.Trim() == String.Empty || textBox3.Text.Trim() == String.Empty)
            {
                flag = 3;
            }
            for (int i = 0; i < gd.totalnum; i++)
            {
                if (goodshelf[i].num == textBox1.Text&&goodshelf[i].gd_num == textBox3.Text)
                {
                    flag = 1;
                    break;
                }
            }
            if (flag == 1)
            {
                MessageBox.Show("该仓库已存在该货架编号");
            }
            if (flag == 0)
            {
                goodshelf[gd.totalnum].num = textBox1.Text;
                goodshelf[gd.totalnum].layer = textBox2.Text;
                goodshelf[gd.totalnum].gd_num = textBox3.Text;
                textBox1.Clear();
                textBox2.Clear();
                gd.totalnum++;
                gd.savefile(goodshelf);
                MessageBox.Show("添加成功,请刷新！");
                this.Close();
            }
            if (flag == 3)
            {
                MessageBox.Show("请把信息填写完整！");
            }
        }
    }
}

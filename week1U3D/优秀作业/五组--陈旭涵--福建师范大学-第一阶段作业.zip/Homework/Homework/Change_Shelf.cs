﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework
{
    public partial class Change_Shelf : Form
    {
        Shelf.goodshelfs[] goodshelf = new Shelf.goodshelfs[100];
        public Change_Shelf()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)//清空
        {
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button3_Click(object sender, EventArgs e)//取消
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)//确定
        {
            int isEmpty = 1;
            int isSave = 0;//是否完成修改
            int  is_godown = 0;//修改的仓库是否存在
            int is_goodshelf = 0;//是否仓库已存在该货架
            Shelf sf = new Shelf();
            sf.loadfile(goodshelf);
            godown gd = new godown();
            godown.warehouses []warehouse= new godown.warehouses[100];
            gd.loadfile(warehouse);
            
            if (textBox2.Text.Trim() != String.Empty || textBox3.Text.Trim() != String.Empty)
            {
                isEmpty = 0;
                if (textBox2.Text.Trim() != String.Empty&& textBox3.Text.Trim() == String.Empty)
                {
                    is_godown = 1;
                    for (int i = 0; i < sf.totalnum; i++)
                    {
                        if (goodshelf[i].num == Shelf.need_change1)
                        {
                            goodshelf[i].layer = textBox2.Text;
                            isSave = 1;
                            break;
                        }
                    }
                }
                else
                {
                    for (int i = 0; i < sf.totalnum; i++)
                    {
                        if (goodshelf[i].num == Shelf.need_change1 && goodshelf[i].gd_num == textBox3.Text)
                        {
                            is_goodshelf = 1;
                        }
                    }
                }
                if (textBox2.Text.Trim()== String.Empty && textBox3.Text.Trim() != String.Empty&&is_goodshelf==0)
                {
                    for (int j = 0; j < gd.totalnum; j++)
                    {
                        if (textBox3.Text == warehouse[j].num)
                        {
                            is_godown = 1;
                            for (int i = 0; i < sf.totalnum; i++)
                            {
                                if (goodshelf[i].num == Shelf.need_change1&& goodshelf[i].layer == Shelf.need_change2 && goodshelf[i].gd_num == Shelf.need_change3)
                                {
                                    goodshelf[i].gd_num = textBox3.Text;
                                    isSave = 1;
                                    break;
                                }
                            }
                        }
                    }
                }
                if (textBox2.Text.Trim() != String.Empty && textBox3.Text.Trim() != String.Empty && is_goodshelf == 0)
                {
                    for (int j = 0; j < gd.totalnum; j++)
                    {
                        if (textBox3.Text == warehouse[j].num)
                        {
                            is_godown = 1;
                            for (int i = 0; i < sf.totalnum; i++)
                            {
                                if (goodshelf[i].num == Shelf.need_change1 && goodshelf[i].layer == Shelf.need_change2 && goodshelf[i].gd_num == Shelf.need_change3)
                                {
                                    goodshelf[i].gd_num = textBox3.Text;
                                    goodshelf[i].layer = textBox2.Text;
                                    isSave = 1;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            if (is_goodshelf == 1)
            {
                MessageBox.Show("修改的仓库已存在相同编号的货架，请选择其他仓库！");
            }
            if (is_godown == 0&& is_goodshelf == 0)
            {
                MessageBox.Show("修改的仓库不存在，请去仓库信息管理中确认！");
            }
            if (isEmpty == 1)
            {
                MessageBox.Show("文本框不能全为空！");
            }
            if (isSave == 1)
            {
                sf.savefile(goodshelf);
                MessageBox.Show("修改成功,请刷新！");
                this.Close();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework
{
    public partial class Search_Merchandise : Form
    {
        Merchandise.goods[] good = new Merchandise.goods[100];
        public Search_Merchandise()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Search_Merchandise_Load(object sender, EventArgs e)
        {
            this.listView1.Columns.Add("商品编号");
            this.listView1.Columns.Add("名称");
            this.listView1.Columns.Add("类型");
            this.listView1.Columns.Add("单价");
            this.listView1.Columns.Add("计量单位");
            this.listView1.Columns.Add("数量");
            this.listView1.View = System.Windows.Forms.View.Details;
            
        }

        private void button1_Click(object sender, EventArgs e)//查询
        {
            listView1.Items.Clear();
            Merchandise mc = new Merchandise();
            mc.loadfile( good);
            for (int i = 0; i < mc.totalnum; i++)
            {
                if ((textBox1.Text.Trim() == String.Empty || textBox1.Text == good[i].num) &&
                    (textBox2.Text.Trim() == String.Empty || textBox2.Text == good[i].name) &&
                    (textBox3.Text.Trim() == String.Empty || textBox3.Text == good[i].type) &&
                    (textBox4.Text.Trim() == String.Empty || textBox4.Text == good[i].price.ToString()) &&
                    (textBox5.Text.Trim() == String.Empty || textBox5.Text == good[i].unitage) &&
                    (textBox6.Text.Trim() == String.Empty || textBox6.Text == good[i].quantity.ToString()))
                {
                    ListViewItem lv = new ListViewItem();
                    lv.Text = good[i].num;
                    lv.SubItems.Add(good[i].name);
                    lv.SubItems.Add(good[i].type);
                    lv.SubItems.Add(good[i].price.ToString());
                    lv.SubItems.Add(good[i].unitage);
                    lv.SubItems.Add(good[i].quantity.ToString());
                    this.listView1.Items.Add(lv);
                }
            }
            MessageBox.Show("查询完成！");
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
        }
    }
}

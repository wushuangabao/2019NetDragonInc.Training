﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework
{
    public partial class Search_Shelf : Form
    {
        Shelf.goodshelfs[] goodshelf = new Shelf.goodshelfs[100];
        public Search_Shelf()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)//清空
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button3_Click(object sender, EventArgs e)//取消
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)//确定
        {
            listView1.Items.Clear();
            Shelf sf= new Shelf();
            sf.loadfile(goodshelf);
            for (int i = 0; i < sf.totalnum; i++)
            {
                if ((textBox1.Text.Trim() == String.Empty || textBox1.Text == goodshelf[i].num) &&
                    (textBox2.Text.Trim() == String.Empty || textBox2.Text == goodshelf[i].layer) &&
                    (textBox3.Text.Trim() == String.Empty || textBox3.Text == goodshelf[i].gd_num))
                {
                    ListViewItem lv = new ListViewItem();
                    lv.Text = goodshelf[i].num;
                    lv.SubItems.Add(goodshelf[i].layer);
                    lv.SubItems.Add(goodshelf[i].gd_num);
                    this.listView1.Items.Add(lv);
                }
            }
            MessageBox.Show("查询完成！");
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Search_Shelf_Load(object sender, EventArgs e)
        {
            this.listView1.Columns.Add("货架编号");
            this.listView1.Columns.Add("总层数");
            this.listView1.Columns.Add("所在仓库编号");
            this.listView1.View = System.Windows.Forms.View.Details;
        }
    }
}

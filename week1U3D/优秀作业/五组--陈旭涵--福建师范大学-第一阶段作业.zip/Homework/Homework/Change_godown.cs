﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework
{
    
    public partial class Change_godown : Form
    {
        godown.warehouses[] warehouse = new godown.warehouses[100];
        public Change_godown()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//确定
        {
            int isEmpty = 1;
            int isSave = 1;
            godown mc = new godown();
            mc.loadfile(warehouse);
            for (int i = 0; i < mc.totalnum; i++)
            {
                if (warehouse[i].num == godown.need_change)
                {
                    if (textBox1.Text.Trim() != String.Empty)
                    {
                        for (int j = 0; j < warehouse.Length; j++)
                        {
                            if (textBox1.Text == warehouse[j].num)
                            {
                                MessageBox.Show("该编号已存在");
                                isSave = 0;
                                break;
                            }
                        }
                        warehouse[i].num = textBox1.Text;
                        isEmpty = 0;
                    }
                    if (textBox2.Text.Trim() != String.Empty)
                    {
                        for (int j = 0; j < warehouse.Length; j++)
                        {
                            if (textBox2.Text == warehouse[j].num)
                            {
                                MessageBox.Show("该地址已存在");
                                isSave = 0;
                                break;
                            }
                        }
                        warehouse[i].addr = textBox2.Text;
                        isEmpty = 0;
                    }
                    break;
                }
            }
            if (isEmpty == 1)
            {
                MessageBox.Show("文本框不能全为空！");
            }
            if (isSave == 0)
            {
                textBox1.Clear();
                textBox2.Clear();
            }
            else
            {
                mc.savefile(warehouse);
                MessageBox.Show("修改成功，请刷新！");
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)//清空
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button3_Click(object sender, EventArgs e)//取消
        {
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework
{
    public partial class Total_Value : Form
    {
        public Total_Value()
        {
            InitializeComponent();
        }

        private void Total_Value_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)//查询
        {
            float total=0;
            Go_Come.goods_max []good_max = new Go_Come.goods_max[100];
            Go_Come gc = new Go_Come();
            gc.loadfile(good_max);
            for (int i = 0; i < gc.totalnum; i++)
            {
                if (good_max[i].gd_num == textBox2.Text)
                {
                    total += good_max[i].price * good_max[i].quantity;
                }
            }
            textBox1.Text = total.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

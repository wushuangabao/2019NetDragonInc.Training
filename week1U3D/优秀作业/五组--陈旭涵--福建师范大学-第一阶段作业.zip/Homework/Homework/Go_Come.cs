﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Homework
{
    public partial class Go_Come : Form
    {
        public goods_max[] good_max = new goods_max[100];
        godown.warehouses[] warehouse = new godown.warehouses[100];
        Merchandise.goods[] good = new Merchandise.goods[100];
        Shelf.goodshelfs[] goodshelf = new Shelf.goodshelfs[100];
        public int totalnum = 0;
        public Go_Come()
        {
            InitializeComponent();
        }
        public struct goods_max
        {
            public String num;//编号
            public String name;//名称
            public String type;//类型
            public float price;//价格
            public String unitage;//计数单位
            public int quantity;//数量
            public String gd_num;//仓库编号
            public String shelf_num;//货架编号
        }
        public void loadfile(goods_max[] b)//读取txt文件
        {
            StreamReader sr = new StreamReader("goods_max.txt");
            totalnum = 0;
            String line;
            String[] a = new String[8];
            int i = 0;
            while ((line = sr.ReadLine()) != null)
            {
                a = line.Split(' ');
                b[i].num = a[0];
                b[i].name = a[1];
                b[i].type = a[2];
                b[i].price = float.Parse(a[3]);
                b[i].unitage = a[4];
                b[i].quantity = int.Parse(a[5]);
                b[i].gd_num = a[6];
                b[i].shelf_num = a[7];
                i++;
                totalnum++;
            }
            sr.Close();
        }
        public void savefile(goods_max[] b)//保存txt文件
        {
            FileStream sw = new FileStream("goods_max.txt", FileMode.Create, FileAccess.Write);
            sw.SetLength(0);//清空txt文本
            sw.Close();
            StreamWriter sr = new StreamWriter("goods_max.txt", true);
            for (int i = 0; i < totalnum; i++)
            {
                sr.WriteLine(b[i].num + " " + b[i].name + " " + b[i].type + " " + b[i].price.ToString() + " " + b[i].unitage + " " + b[i].quantity.ToString()+" "+b[i].gd_num + " " + b[i].shelf_num);
            }

            sr.Close();
        }

        public void update()//刷新
        {
            listView1.Items.Clear();
            totalnum = 0;
            loadfile(good_max);
            for (int i = 0; i < totalnum; i++)
            {
                ListViewItem lv = new ListViewItem();
                lv.Text = good_max[i].num;
                lv.SubItems.Add(good_max[i].name);
                lv.SubItems.Add(good_max[i].type);
                lv.SubItems.Add(good_max[i].price.ToString());
                lv.SubItems.Add(good_max[i].unitage);
                lv.SubItems.Add(good_max[i].quantity.ToString());
                lv.SubItems.Add(good_max[i].gd_num);
                lv.SubItems.Add(good_max[i].shelf_num);
                this.listView1.Items.Add(lv);
            }
        }
        private void button3_Click(object sender, EventArgs e)//退出
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox3.Clear();
        }

        private void Go_Come_Load(object sender, EventArgs e)
        {
            this.listView1.Columns.Add("商品编号");
            this.listView1.Columns.Add("名称");
            this.listView1.Columns.Add("类型");
            this.listView1.Columns.Add("价格");
            this.listView1.Columns.Add("计数单位");
            this.listView1.Columns.Add("数量");
            this.listView1.Columns.Add("仓库编号");
            this.listView1.Columns.Add("货架编号");
            this.listView1.View = System.Windows.Forms.View.Details;
            update();
        }

        private void button1_Click(object sender, EventArgs e)//出库
        {
            ListView lv = this.listView1;
            Merchandise.goods []good = new Merchandise.goods[100];
            Merchandise mc = new Merchandise();
            mc.loadfile(good);
            int sl_good=0;//储存准备出库商品在商品信息管理类数组中的索引号
            if (lv.SelectedItems.Count > 0)
            {
                if (textBox4.Text.Trim() != String.Empty)
                {
                    for (int i = 0; i < totalnum; i++)
                    {
                        if (lv.SelectedItems[0].SubItems[0].Text == good_max[i].num && lv.SelectedItems[0].SubItems[6].Text == good_max[i].gd_num&& lv.SelectedItems[0].SubItems[7].Text == good_max[i].shelf_num)
                        {
                            for (int m = 0; m < mc.totalnum; m++)
                            {
                                if (good[m].num == lv.SelectedItems[0].SubItems[0].Text)
                                {
                                    sl_good = m;
                                    break;
                                }
                            }
                            if ((good_max[i].quantity - int.Parse(textBox4.Text) > 0))
                            {
                                good_max[i].quantity = good_max[i].quantity - int.Parse(textBox4.Text);
                                good[sl_good].quantity -= int.Parse(textBox4.Text);
                            }
                            else if ((good_max[i].quantity - int.Parse(textBox4.Text) < 0))
                            {
                                MessageBox.Show("该商品库存不足，出库失败！");
                            }
                            else if ((good_max[i].quantity - int.Parse(textBox4.Text) == 0))
                            {
                                good[sl_good].quantity -= int.Parse(textBox4.Text);
                                if (good[sl_good].quantity == 0)
                                {
                                    for (int l = i; l < mc.totalnum - 1; l++)
                                    {
                                        good_max[l] = good_max[l + 1];
                                    }
                                    mc.totalnum--;
                                }
                                for (int j = i; j < totalnum - 1; j++)
                                {
                                    good_max[j] = good_max[j + 1];
                                }
                                totalnum--;
                            }
                            break;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("请填入要出库商品的数量！");
                }
            }
            else
            {
                int flag = 0;//仓库是否存在准备出库的商品 0无 1有
                if (textBox1.Text.Trim() != String.Empty && textBox2.Text.Trim() != String.Empty && textBox4.Text.Trim() != String.Empty && textBox5.Text.Trim() != String.Empty && textBox3.Text.Trim() != String.Empty)
                {
                    for (int i = 0; i < totalnum; i++)
                    {
                        if (textBox1.Text == good_max[i].num && textBox2.Text == good_max[i].name  && textBox5.Text == good_max[i].gd_num && textBox3.Text == good_max[i].shelf_num)
                        {
                            flag = 1;
                            for (int m = 0; m < mc.totalnum; m++)
                            {
                                if (good[m].num == textBox1.Text)
                                {
                                    sl_good = m;
                                    break;
                                }
                            }
                            if ((good_max[i].quantity - int.Parse(textBox4.Text) > 0))
                            {
                                good_max[i].quantity = good_max[i].quantity - int.Parse(textBox4.Text);
                                good[sl_good].quantity -= int.Parse(textBox4.Text);
                            }
                            else if ((good_max[i].quantity - int.Parse(textBox4.Text) < 0))
                            {
                                MessageBox.Show("该商品库存不足，出库失败！");
                            }
                            else if ((good_max[i].quantity - int.Parse(textBox4.Text) == 0))
                            {
                                good[sl_good].quantity -= int.Parse(textBox4.Text);
                                if (good[sl_good].quantity == 0)
                                {
                                    for (int l = i; l < mc.totalnum - 1; l++)
                                    {
                                        good_max[l] = good_max[l + 1];
                                    }
                                    mc.totalnum--;
                                }
                                for (int j = i; j < totalnum - 1; j++)
                                {
                                    good_max[j] = good_max[j + 1];
                                }
                                totalnum--;
                            }
                            break;
                        }
                    }
                    if(flag==0)
                    {
                        MessageBox.Show("填入的信息有误！");
                    }
                }
                else
                {
                    MessageBox.Show("请在列表中选择出库商品或完整填写出库商品信息！");
                }
            }
            savefile(good_max);
            mc.savefile(good);
            update();
        }

        private void button2_Click(object sender, EventArgs e)//入库
        {
            int isexsit_shelf = 0;//入库货架是否有在货架信息管理中存在
            int isexsit_good = 0;//入库商品是否有在商品信息管理中存在
            int good_num=0;//若入库商品存在储存其在数组中的索引号
            int isexsit_warehouse = 0;//仓库是否存在
            godown gd = new godown();
            gd.loadfile(warehouse);
            Merchandise mc = new Merchandise();
            mc.loadfile(good);
            Shelf sf = new Shelf();
            sf.loadfile(goodshelf);
            if (textBox1.Text.Trim() != String.Empty && textBox2.Text.Trim() != String.Empty&& textBox4.Text.Trim() != String.Empty && textBox5.Text.Trim() != String.Empty && textBox3.Text.Trim() != String.Empty)
            {
                for (int n = 0; n < mc.totalnum; n++)
                {
                    if (textBox1.Text == good[n].num && textBox2.Text == good[n].name)
                    {
                        isexsit_good = 1;
                        good_num = n;
                        break;
                    }
                }
                for (int q = 0; q < gd.totalnum; q++)
                {
                    if (textBox5.Text == warehouse[q].num)
                    {
                        isexsit_warehouse = 1;
                        for (int n = 0; n < sf.totalnum; n++)
                        {
                            if (textBox3.Text == goodshelf[n].num&& textBox5.Text== goodshelf[n].gd_num)
                            {
                                isexsit_shelf = 1;
                                break;
                            }
                        }
                        break;
                    }
                }
                if (isexsit_shelf == 0)
                {
                    MessageBox.Show("该仓库不存在该货架或填写信息有误，请去货架信息管理中确认货架信息！");
                }
                if (isexsit_warehouse == 0)
                {
                    MessageBox.Show("不存在该仓库或填写信息有误，请去仓库信息管理中确认仓库信息！");
                }
                if (isexsit_good == 0)
                {
                    MessageBox.Show("不存在该商品或填写信息有误，请去商品信息管理中确认商品信息！");
                }
                if (isexsit_good == 1&&isexsit_warehouse==1&&isexsit_shelf == 1)
                {
                    int flag = 0;//判断指定仓库是否已存在准备入库的商品 0为无 1为有
                    for (int i = 0; i < totalnum; i++)
                    {
                        if (textBox5.Text == good_max[i].gd_num&& textBox3.Text == good_max[i].shelf_num)
                        {
                            if (textBox1.Text == good_max[i].num)
                            {
                                good_max[i].quantity += int.Parse(textBox4.Text);
                                good[good_num].quantity+= int.Parse(textBox4.Text);
                                flag = 1;
                            }
                        }
                    }
                    if (flag == 0)
                    {
                        good_max[totalnum].num = good[good_num].num;
                        good_max[totalnum].name = good[good_num].name;
                        good_max[totalnum].type = good[good_num].type;
                        good_max[totalnum].price = good[good_num].price;
                        good_max[totalnum].unitage = good[good_num].unitage;
                        good_max[totalnum].quantity = int.Parse(textBox4.Text);
                        good_max[totalnum].gd_num = textBox5.Text;
                        good_max[totalnum].shelf_num = textBox3.Text;
                        good[good_num].quantity += int.Parse(textBox4.Text);
                        totalnum++;
                    }
                }
            }
            else
            {
                MessageBox.Show("请把信息填写完整！");
            }
            savefile(good_max);
            mc.savefile(good);
            update();
        }

        
    }
}

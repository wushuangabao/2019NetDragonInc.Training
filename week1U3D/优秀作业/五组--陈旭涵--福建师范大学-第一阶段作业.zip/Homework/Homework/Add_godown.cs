﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework
{
    public partial class Add_godown : Form
    {
        godown gd = new godown();
        godown.warehouses[] warehouse = new godown.warehouses[100];
        public Add_godown()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//确定
        {
            gd.loadfile(warehouse);
            int flag = 0;
            if (textBox1.Text.Trim() == String.Empty||textBox2.Text.Trim()==String.Empty)
            {
                flag = 3;
            }
            for (int i = 0; i < gd.totalnum; i++)
            {
                if (warehouse[i].num == textBox1.Text)
                {
                    flag = 1;
                    break;
                }
                if (warehouse[i].addr == textBox2.Text)
                {
                    flag = 2;
                    break;
                }
            }
            if (flag == 1)
            {
                MessageBox.Show("该仓库编号已存在");
            }
            if (flag == 2)
            {
                MessageBox.Show("该地址已存在");
            }
            if (flag == 0)
            {
                warehouse[gd.totalnum].num = textBox1.Text;
                warehouse[gd.totalnum].addr = textBox2.Text;
                textBox1.Clear();
                textBox2.Clear();
                gd.totalnum++;
                gd.savefile(warehouse);
                MessageBox.Show("添加成功,请刷新！");
                this.Close();
            }
            if (flag == 3)
            {
                MessageBox.Show("请把信息填写完整！");
            }
        }

        private void button2_Click(object sender, EventArgs e)//清空
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button3_Click(object sender, EventArgs e)//取消
        {
            this.Close();
        }
    }
}

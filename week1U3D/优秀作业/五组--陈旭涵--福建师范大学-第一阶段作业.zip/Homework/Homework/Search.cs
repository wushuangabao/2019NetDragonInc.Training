﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework
{
    public partial class Search : Form
    {
        Merchandise.goods[] good = new Merchandise.goods[100];
        Go_Come.goods_max[] good_max = new Go_Come.goods_max[100];
        public Search()
        {
            InitializeComponent();
        }

        private void Search_Load(object sender, EventArgs e)
        {
            this.listView1.Columns.Add("商品编号");
            this.listView1.Columns.Add("名称");
            this.listView1.Columns.Add("类型");
            this.listView1.Columns.Add("单价");
            this.listView1.Columns.Add("计量单位");
            this.listView1.Columns.Add("数量");
            this.listView1.View = System.Windows.Forms.View.Details;
        }

        private void button2_Click(object sender, EventArgs e)//按类型查询
        {
            if (textBox1.Text.Trim() != String.Empty)
            {
                MessageBox.Show("按类型查询不能填写仓库编号！");
                textBox1.Clear();
            }
            if (textBox2.Text.Trim() == String.Empty)
            {
                MessageBox.Show("请填写需查询的商品类型！");
            }
            Merchandise mc = new Merchandise();
            Merchandise.goods[] order_good = new Merchandise.goods[100];
            int n = 0;
            mc.loadfile(good);
            for (int i = 0; i < mc.totalnum; i++)
            {
                if (good[i].type == textBox2.Text)
                {
                    order_good[n] = good[i];
                    n++;
                }
            }
            for (int i = 0; i < n - 1; i++)
            {
                Merchandise.goods tex = new Merchandise.goods();
                for (int j = i + 1; j < n; j++)
                {
                    if (order_good[i].quantity < order_good[j].quantity)
                    {
                        tex = order_good[i];
                        order_good[i] = order_good[j];
                        order_good[j] = tex;
                    }
                }
            }
            listView1.Items.Clear();
            for (int i = 0; i < n; i++)
            {
                if (i > 2)
                    break;

                ListViewItem lv = new ListViewItem();
                lv.Text = order_good[i].num;
                lv.SubItems.Add(order_good[i].name);
                lv.SubItems.Add(order_good[i].type);
                lv.SubItems.Add(order_good[i].price.ToString());
                lv.SubItems.Add(order_good[i].unitage);
                lv.SubItems.Add(order_good[i].quantity.ToString());
                this.listView1.Items.Add(lv);
            }
            //textBox2.Clear();
        }

        private void button3_Click(object sender, EventArgs e)//退出
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)//清空
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button1_Click(object sender, EventArgs e)//按仓库查询
        {

            if (textBox2.Text.Trim() != String.Empty)
            {
                MessageBox.Show("按类型查询不能填写商品类型！");
                textBox2.Clear();
            }
            if (textBox1.Text.Trim() == String.Empty)
            {
                MessageBox.Show("请填写需查询的仓库编号！");
            }
            Go_Come gc = new Go_Come();
            Go_Come.goods_max[] order_good_max = new Go_Come.goods_max[100];
            int n = 0;
            gc.loadfile(good_max);
            for (int i = 0; i < gc.totalnum; i++)
            {
                if (good_max[i].gd_num == textBox1.Text)
                {
                    order_good_max[n] = good_max[i];
                    n++;
                }
            }
            for (int i = 0; i < n - 1; i++)
            {
                Go_Come.goods_max tex = new Go_Come.goods_max();
                for (int j = i + 1; j < n; j++)
                {
                    if (order_good_max[i].quantity < order_good_max[j].quantity)
                    {
                        tex = order_good_max[i];
                        order_good_max[i] = order_good_max[j];
                        order_good_max[j] = tex;
                    }
                }
            }
            listView1.Items.Clear();
            for (int i = 0; i < n; i++)
            {
                if (i > 2)
                    break;

                ListViewItem lv = new ListViewItem();
                lv.Text = order_good_max[i].num;
                lv.SubItems.Add(order_good_max[i].name);
                lv.SubItems.Add(order_good_max[i].type);
                lv.SubItems.Add(order_good_max[i].price.ToString());
                lv.SubItems.Add(order_good_max[i].unitage);
                lv.SubItems.Add(order_good_max[i].quantity.ToString());
                this.listView1.Items.Add(lv);
            }
            //textBox1.Clear();
        }
    }
}
